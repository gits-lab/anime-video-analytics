/**
 * B站公开API服务
 * 获取真实视频数据（播放量、点赞数等）
 */

// B站视频数据接口
export interface BilibiliVideo {
  bvid: string;
  aid: number;
  title: string;
  author: string;
  mid: number; // UP主ID
  view_count: number;
  like_count: number;
  coin_count: number;
  favorite_count: number;
  share_count: number;
  comment_count: number;
  danmaku_count: number;
  pubdate: number;
  desc: string;
  pic: string;
  tags: string[];
  duration: number;
  video_url: string;
}

// B站搜索结果
interface BilibiliSearchResult {
  type: string;
  id: number;
  author: string;
  mid: number;
  title: string;
  pic: string;
  play: number; // 播放量
  video_review: number; // 弹幕数
  comment: number; // 评论数
  favorites: number; // 收藏数
  danmaku: number;
  pubdate: number;
  senddate: number;
  duration: string;
  bvid: string;
  tag: string;
  description: string;
}

// B站API响应
interface BilibiliApiResponse<T> {
  code: number;
  message: string;
  data: T;
}

// 请求头配置 - 模拟浏览器请求
const BILIBILI_HEADERS = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Referer': 'https://www.bilibili.com/',
  'Origin': 'https://www.bilibili.com',
  'Accept': 'application/json, text/plain, */*',
  'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
  'Accept-Encoding': 'gzip, deflate, br',
  'Connection': 'keep-alive',
  'Sec-Fetch-Dest': 'empty',
  'Sec-Fetch-Mode': 'cors',
  'Sec-Fetch-Site': 'same-site',
  // B站需要这个Cookie来绕过基础验证
  'Cookie': 'buvid3=geninf; buvid4=geninf; _uuid=geninf; buvid_fp=geninf; fingerprint=geninf; buvid_fp_plain=geninf',
};

/**
 * 搜索B站视频
 */
export async function searchBilibiliVideos(
  keyword: string,
  page: number = 1,
  pageSize: number = 20
): Promise<BilibiliVideo[]> {
  try {
    const url = new URL('https://api.bilibili.com/x/web-interface/search/type');
    url.searchParams.set('search_type', 'video');
    url.searchParams.set('keyword', keyword);
    url.searchParams.set('page', page.toString());
    url.searchParams.set('page_size', pageSize.toString());
    url.searchParams.set('order', 'totalrank'); // 综合排序

    const response = await fetch(url.toString(), {
      method: 'GET',
      headers: BILIBILI_HEADERS,
    });

    if (!response.ok) {
      console.error(`[Bilibili API] Search failed: ${response.status}`);
      return [];
    }

    const result: BilibiliApiResponse<{
      result: BilibiliSearchResult[];
      numResults: number;
    }> = await response.json();

    if (result.code !== 0) {
      console.error(`[Bilibili API] API error: ${result.message}`);
      return [];
    }

    // 转换搜索结果为标准格式
    const videos: BilibiliVideo[] = [];
    for (const item of result.data.result || []) {
      // 解析标题（去除HTML标签）
      const title = item.title
        .replace(/<em class="keyword">/g, '')
        .replace(/<\/em>/g, '')
        .replace(/<[^>]+>/g, '');

      // 解析标签
      const tags = item.tag ? item.tag.split(',').filter((t: string) => t.trim()) : [];

      videos.push({
        bvid: item.bvid,
        aid: item.id,
        title: title,
        author: item.author || '未知UP主',
        mid: item.mid,
        view_count: item.play || 0,
        like_count: 0, // 搜索结果不含点赞数，需要单独获取
        coin_count: 0,
        favorite_count: item.favorites || 0,
        share_count: 0,
        comment_count: item.comment || 0,
        danmaku_count: item.danmaku || 0,
        pubdate: item.pubdate * 1000, // 转为毫秒
        desc: item.description || '',
        pic: item.pic.startsWith('//') ? `https:${item.pic}` : item.pic,
        tags: tags,
        duration: parseDuration(item.duration),
        video_url: `https://www.bilibili.com/video/${item.bvid}`,
      });
    }

    return videos;
  } catch (error) {
    console.error('[Bilibili API] Search error:', error);
    return [];
  }
}

/**
 * 获取视频详细信息（包含点赞数等）
 */
export async function getVideoDetail(bvid: string): Promise<BilibiliVideo | null> {
  try {
    const url = `https://api.bilibili.com/x/web-interface/view?bvid=${bvid}`;

    const response = await fetch(url, {
      method: 'GET',
      headers: BILIBILI_HEADERS,
    });

    if (!response.ok) {
      console.error(`[Bilibili API] Get detail failed: ${response.status}`);
      return null;
    }

    const result: BilibiliApiResponse<{
      bvid: string;
      aid: number;
      title: string;
      owner: { mid: number; name: string };
      stat: {
        view: number;
        like: number;
        coin: number;
        favorite: number;
        share: number;
        danmaku: number;
        reply: number;
      };
      pubdate: number;
      desc: string;
      pic: string;
      tag: string;
      duration: number;
    }> = await response.json();

    if (result.code !== 0) {
      console.error(`[Bilibili API] Get detail error: ${result.message}`);
      return null;
    }

    const data = result.data;
    return {
      bvid: data.bvid,
      aid: data.aid,
      title: data.title,
      author: data.owner.name,
      mid: data.owner.mid,
      view_count: data.stat.view,
      like_count: data.stat.like,
      coin_count: data.stat.coin,
      favorite_count: data.stat.favorite,
      share_count: data.stat.share,
      comment_count: data.stat.reply,
      danmaku_count: data.stat.danmaku,
      pubdate: data.pubdate * 1000,
      desc: data.desc,
      pic: data.pic,
      tags: data.tag.split(',').filter(t => t.trim()),
      duration: data.duration,
      video_url: `https://www.bilibili.com/video/${data.bvid}`,
    };
  } catch (error) {
    console.error('[Bilibili API] Get detail error:', error);
    return null;
  }
}

/**
 * 获取热门视频
 */
export async function getPopularVideos(
  pageSize: number = 20,
  categoryId: number = 13 // 13 = 动画分区
): Promise<BilibiliVideo[]> {
  try {
    const url = `https://api.bilibili.com/x/web-interface/popular?ps=${pageSize}&pn=1`;

    const response = await fetch(url, {
      method: 'GET',
      headers: BILIBILI_HEADERS,
    });

    if (!response.ok) {
      console.error(`[Bilibili API] Get popular failed: ${response.status}`);
      return [];
    }

    const result: BilibiliApiResponse<{
      list: Array<{
        bvid: string;
        aid: number;
        title: string;
        owner: { mid: number; name: string };
        stat: {
          view: number;
          like: number;
          coin: number;
          favorite: number;
          share: number;
          danmaku: number;
          reply: number;
        };
        pubdate: number;
        desc: string;
        pic: string;
        tname: string;
        duration: number;
      }>;
    }> = await response.json();

    if (result.code !== 0) {
      console.error(`[Bilibili API] Get popular error: ${result.message}`);
      return [];
    }

    return (result.data.list || []).map(item => ({
      bvid: item.bvid,
      aid: item.aid,
      title: item.title,
      author: item.owner.name,
      mid: item.owner.mid,
      view_count: item.stat.view,
      like_count: item.stat.like,
      coin_count: item.stat.coin,
      favorite_count: item.stat.favorite,
      share_count: item.stat.share,
      comment_count: item.stat.reply,
      danmaku_count: item.stat.danmaku,
      pubdate: item.pubdate * 1000,
      desc: item.desc,
      pic: item.pic,
      tags: item.tname ? [item.tname] : [],
      duration: item.duration,
      video_url: `https://www.bilibili.com/video/${item.bvid}`,
    }));
  } catch (error) {
    console.error('[Bilibili API] Get popular error:', error);
    return [];
  }
}

/**
 * 获取分区热门视频（动画区）- 改用热门视频API
 */
export async function getRankingVideos(
  rid: number = 13 // 13 = 动画分区（参数保留但实际使用热门视频API）
): Promise<BilibiliVideo[]> {
  try {
    // 使用热门视频API获取数据（更稳定）
    const url = `https://api.bilibili.com/x/web-interface/popular?ps=50&pn=1`;

    const response = await fetch(url, {
      method: 'GET',
      headers: BILIBILI_HEADERS,
    });

    if (!response.ok) {
      console.error(`[Bilibili API] Get popular failed: ${response.status}`);
      return [];
    }

    const result: BilibiliApiResponse<{
      list: Array<{
        bvid: string;
        aid: number;
        title: string;
        owner: { mid: number; name: string };
        stat: {
          view: number;
          like: number;
          coin: number;
          favorite: number;
          share: number;
          danmaku: number;
          reply: number;
        };
        pubdate: number;
        desc: string;
        pic: string;
        tname: string;
        duration: number;
      }>;
    }> = await response.json();

    if (result.code !== 0) {
      console.error(`[Bilibili API] Get popular error: ${result.message}`);
      return [];
    }

    // 过滤动漫相关视频
    const animeKeywords = ['动画', '动漫', '二次元', '番剧', 'MAD', 'AMV', '国漫', '日漫', '新番', '声优', 'Cosplay', '手办', '鬼畜'];
    
    return (result.data.list || [])
      .filter(item => {
        const titleLower = item.title.toLowerCase();
        const tnameLower = (item.tname || '').toLowerCase();
        return animeKeywords.some(kw => 
          titleLower.includes(kw.toLowerCase()) || 
          tnameLower.includes(kw.toLowerCase()) ||
          (item.desc || '').toLowerCase().includes(kw.toLowerCase())
        );
      })
      .slice(0, 30)
      .map(item => ({
        bvid: item.bvid,
        aid: item.aid,
        title: item.title,
        author: item.owner.name,
        mid: item.owner.mid,
        view_count: item.stat.view,
        like_count: item.stat.like || 0,
        coin_count: item.stat.coin || 0,
        favorite_count: item.stat.favorite || 0,
        share_count: item.stat.share || 0,
        comment_count: item.stat.reply || 0,
        danmaku_count: item.stat.danmaku || 0,
        pubdate: item.pubdate * 1000,
        desc: item.desc,
        pic: item.pic,
        tags: item.tname ? [item.tname] : [],
        duration: item.duration,
        video_url: `https://www.bilibili.com/video/${item.bvid}`,
      }));
  } catch (error) {
    console.error('[Bilibili API] Get popular error:', error);
    return [];
  }
}

/**
 * 解析时长字符串
 */
function parseDuration(durationStr: string): number {
  if (!durationStr) return 0;
  
  // 格式: "MM:SS" 或 "HH:MM:SS"
  const parts = durationStr.split(':').map(Number);
  if (parts.length === 2) {
    return parts[0] * 60 + parts[1];
  } else if (parts.length === 3) {
    return parts[0] * 3600 + parts[1] * 60 + parts[2];
  }
  return 0;
}

/**
 * 批量获取视频详情
 */
export async function batchGetVideoDetails(
  bvids: string[],
  delay: number = 200
): Promise<BilibiliVideo[]> {
  const videos: BilibiliVideo[] = [];
  
  for (const bvid of bvids) {
    const video = await getVideoDetail(bvid);
    if (video) {
      videos.push(video);
    }
    // 添加延迟避免请求过快
    await new Promise(resolve => setTimeout(resolve, delay));
  }
  
  return videos;
}

/**
 * 综合爬取：搜索 + 获取详情
 */
export async function crawlBilibiliWithStats(
  keywords: string[],
  videosPerKeyword: number = 10,
  onProgress?: (message: string) => void
): Promise<BilibiliVideo[]> {
  const allVideos: BilibiliVideo[] = [];
  const seenBvids = new Set<string>();

  for (const keyword of keywords) {
    onProgress?.(`正在搜索: ${keyword}`);
    
    // 搜索视频
    const searchResults = await searchBilibiliVideos(keyword, 1, videosPerKeyword);
    
    if (searchResults.length === 0) {
      onProgress?.(`搜索 "${keyword}" 无结果`);
      continue;
    }

    onProgress?.(`搜索 "${keyword}" 找到 ${searchResults.length} 个视频`);

    // 获取视频详情（包含点赞数等）
    const bvids = searchResults
      .filter(v => !seenBvids.has(v.bvid))
      .slice(0, videosPerKeyword)
      .map(v => v.bvid);

    for (let i = 0; i < bvids.length; i++) {
      const bvid = bvids[i];
      if (seenBvids.has(bvid)) continue;
      
      onProgress?.(`获取视频详情: ${bvid} (${i + 1}/${bvids.length})`);
      
      const detail = await getVideoDetail(bvid);
      if (detail) {
        allVideos.push(detail);
        seenBvids.add(bvid);
      }
      
      // 延迟避免请求过快
      await new Promise(resolve => setTimeout(resolve, 300));
    }
  }

  onProgress?.(`共获取 ${allVideos.length} 个视频数据`);
  return allVideos;
}
