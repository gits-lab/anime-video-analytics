import { pgTable, index, serial, varchar, integer, timestamp, text, numeric } from "drizzle-orm/pg-core"
import { sql } from "drizzle-orm"



export const animeVideos = pgTable("anime_videos", {
	id: serial().primaryKey().notNull(),
	platform: varchar({ length: 20 }).notNull(),
	title: varchar({ length: 500 }).notNull(),
	author: varchar({ length: 100 }).notNull(),
	videoUrl: varchar("video_url", { length: 1000 }),
	viewCount: integer("view_count").default(0).notNull(),
	likeCount: integer("like_count").default(0).notNull(),
	commentCount: integer("comment_count").default(0).notNull(),
	favoriteCount: integer("favorite_count").default(0).notNull(),
	shareCount: integer("share_count").default(0).notNull(),
	publishTime: timestamp("publish_time", { withTimezone: true, mode: 'string' }),
	tags: text(),
	coverUrl: varchar("cover_url", { length: 1000 }),
	description: text(),
	interactionRate: numeric("interaction_rate", { precision: 10, scale:  4 }),
	rankScore: numeric("rank_score", { precision: 10, scale:  2 }),
	trendScore: numeric("trend_score", { precision: 10, scale:  2 }),
	lastCrawledAt: timestamp("last_crawled_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow(),
}, (table) => [
	index("anime_videos_interaction_rate_idx").using("btree", table.interactionRate.asc().nullsLast().op("numeric_ops")),
	index("anime_videos_platform_idx").using("btree", table.platform.asc().nullsLast().op("text_ops")),
	index("anime_videos_publish_time_idx").using("btree", table.publishTime.asc().nullsLast().op("timestamptz_ops")),
	index("anime_videos_rank_score_idx").using("btree", table.rankScore.asc().nullsLast().op("numeric_ops")),
	index("anime_videos_view_count_idx").using("btree", table.viewCount.asc().nullsLast().op("int4_ops")),
]);

export const healthCheck = pgTable("health_check", {
	id: serial().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow(),
});

export const crawlTasks = pgTable("crawl_tasks", {
	id: serial().primaryKey().notNull(),
	keyword: varchar({ length: 100 }).notNull(),
	platform: varchar({ length: 20 }).notNull(),
	status: varchar({ length: 20 }).default('pending').notNull(),
	resultCount: integer("result_count").default(0),
	errorMessage: text("error_message"),
	startedAt: timestamp("started_at", { withTimezone: true, mode: 'string' }),
	completedAt: timestamp("completed_at", { withTimezone: true, mode: 'string' }),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("crawl_tasks_created_at_idx").using("btree", table.createdAt.asc().nullsLast().op("timestamptz_ops")),
	index("crawl_tasks_platform_idx").using("btree", table.platform.asc().nullsLast().op("text_ops")),
	index("crawl_tasks_status_idx").using("btree", table.status.asc().nullsLast().op("text_ops")),
]);

export const videoStats = pgTable("video_stats", {
	id: serial().primaryKey().notNull(),
	statDate: timestamp("stat_date", { withTimezone: true, mode: 'string' }).notNull(),
	platform: varchar({ length: 20 }).notNull(),
	totalVideos: integer("total_videos").default(0).notNull(),
	totalViews: integer("total_views").default(0).notNull(),
	totalLikes: integer("total_likes").default(0).notNull(),
	avgInteractionRate: numeric("avg_interaction_rate", { precision: 10, scale:  4 }),
	topTags: text("top_tags"),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow().notNull(),
}, (table) => [
	index("video_stats_date_idx").using("btree", table.statDate.asc().nullsLast().op("timestamptz_ops")),
	index("video_stats_platform_idx").using("btree", table.platform.asc().nullsLast().op("text_ops")),
]);
