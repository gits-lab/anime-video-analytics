import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import {
  searchBilibiliVideos,
  getVideoDetail,
  getRankingVideos,
  type BilibiliVideo,
} from '@/lib/bilibili-api';

// 爬取关键词配置
const CRAWL_KEYWORDS = ['动漫', '二次元', '新番', '动漫解说', '混剪', '国漫'];

// 爬取结果接口
interface CrawledVideo {
  platform: string;
  title: string;
  author: string;
  video_url: string;
  view_count: number;
  like_count: number;
  comment_count: number;
  favorite_count: number;
  share_count: number;
  publish_time: string | null;
  tags: string;
  cover_url: string | null;
  description: string | null;
}

/**
 * 将B站视频数据转换为标准格式
 */
function convertBilibiliVideo(video: BilibiliVideo): CrawledVideo {
  return {
    platform: 'bilibili',
    title: video.title,
    author: video.author,
    video_url: video.video_url,
    view_count: video.view_count,
    like_count: video.like_count,
    comment_count: video.comment_count,
    favorite_count: video.favorite_count,
    share_count: video.share_count,
    publish_time: video.pubdate ? new Date(video.pubdate).toISOString() : null,
    tags: video.tags.join(','),
    cover_url: video.pic,
    description: video.desc,
  };
}

/**
 * 计算互动率
 */
function calculateInteractionRate(video: CrawledVideo): number {
  if (video.view_count === 0) return 0;
  const interactions = video.like_count + video.comment_count + video.favorite_count + video.share_count;
  return parseFloat((interactions / video.view_count * 100).toFixed(4));
}

/**
 * 计算排名分数
 */
function calculateRankScore(video: CrawledVideo): number {
  const viewScore = Math.log10(video.view_count + 1) * 10;
  const interactionScore = Math.log10(video.like_count + video.comment_count + video.favorite_count + 1) * 5;
  return Math.round((viewScore + interactionScore) * 100) / 100;
}

/**
 * 执行慢速爬取
 */
async function performSlowCrawl(): Promise<{ success: boolean; count: number; message: string }> {
  const supabase = getSupabaseClient();
  const allVideos: CrawledVideo[] = [];
  const seenUrls = new Set<string>();

  try {
    // 1. 获取排行榜数据（动画区）
    console.log('[Cron] 正在获取B站动画区排行榜...');
    const rankingVideos = await getRankingVideos(13);
    console.log(`[Cron] 排行榜获取到 ${rankingVideos.length} 个视频`);
    
    for (const video of rankingVideos.slice(0, 20)) { // 只取前20个
      if (!seenUrls.has(video.video_url)) {
        allVideos.push(convertBilibiliVideo(video));
        seenUrls.add(video.video_url);
      }
    }

    // 2. 搜索关键词
    for (const keyword of CRAWL_KEYWORDS.slice(0, 3)) { // 限制关键词数量
      console.log(`[Cron] 正在搜索: ${keyword}`);
      
      await new Promise(resolve => setTimeout(resolve, 1000)); // 慢速延迟
      
      const searchResults = await searchBilibiliVideos(keyword, 1, 10);
      
      for (const searchVideo of searchResults.slice(0, 5)) {
        if (seenUrls.has(searchVideo.video_url)) continue;
        
        await new Promise(resolve => setTimeout(resolve, 500));
        
        const detail = await getVideoDetail(searchVideo.bvid);
        if (detail) {
          allVideos.push(convertBilibiliVideo(detail));
          seenUrls.add(detail.video_url);
        }
      }
    }

    // 3. 存储到数据库
    let insertedCount = 0;
    
    for (const video of allVideos) {
      const interactionRate = calculateInteractionRate(video);
      const rankScore = calculateRankScore(video);

      const { error } = await supabase
        .from('anime_videos')
        .upsert(
          {
            platform: video.platform,
            title: video.title,
            author: video.author,
            video_url: video.video_url,
            view_count: video.view_count,
            like_count: video.like_count,
            comment_count: video.comment_count,
            favorite_count: video.favorite_count,
            share_count: video.share_count,
            publish_time: video.publish_time,
            tags: video.tags,
            cover_url: video.cover_url,
            description: video.description,
            interaction_rate: interactionRate,
            rank_score: rankScore,
            trend_score: 0,
            updated_at: new Date().toISOString(),
          },
          {
            onConflict: 'video_url',
            ignoreDuplicates: false,
          }
        );

      if (!error) {
        insertedCount++;
      }
    }

    // 4. 创建任务记录
    await supabase
      .from('crawl_tasks')
      .insert({
        keyword: CRAWL_KEYWORDS.slice(0, 3).join(','),
        platform: 'bilibili',
        status: 'completed',
        result_count: insertedCount,
        started_at: new Date().toISOString(),
        completed_at: new Date().toISOString(),
      });

    return {
      success: true,
      count: insertedCount,
      message: `定时爬取完成，新增/更新 ${insertedCount} 条数据`,
    };
  } catch (error) {
    console.error('[Cron] 爬取失败:', error);
    return {
      success: false,
      count: 0,
      message: `爬取失败: ${error}`,
    };
  }
}

/**
 * GET /api/cron - 健康检查
 */
export async function GET() {
  return NextResponse.json({
    status: 'ok',
    message: 'Cron endpoint is ready. Use POST to trigger scheduled crawl.',
    timestamp: new Date().toISOString(),
  });
}

/**
 * POST /api/cron - 触发定时爬取
 */
export async function POST(request: NextRequest) {
  console.log('[Cron] 开始定时爬取任务');
  
  const result = await performSlowCrawl();
  
  return NextResponse.json({
    success: result.success,
    message: result.message,
    videos_count: result.count,
    timestamp: new Date().toISOString(),
  });
}
