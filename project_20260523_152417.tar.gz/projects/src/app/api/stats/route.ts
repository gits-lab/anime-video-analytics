import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';

// 概览统计
async function getOverviewStats(supabase: ReturnType<typeof getSupabaseClient>) {
  // 总视频数
  const { count: totalVideos } = await supabase
    .from('anime_videos')
    .select('*', { count: 'exact', head: true });

  // 总播放量
  const { data: viewStats } = await supabase
    .from('anime_videos')
    .select('view_count');

  const totalViews = viewStats?.reduce((sum, v) => sum + (v.view_count || 0), 0) || 0;

  // 总互动量
  const { data: interactionStats } = await supabase
    .from('anime_videos')
    .select('like_count, comment_count, favorite_count, share_count');

  const totalInteractions = interactionStats?.reduce((sum, v) => 
    sum + (v.like_count || 0) + (v.comment_count || 0) + (v.favorite_count || 0) + (v.share_count || 0), 0) || 0;

  // 平均互动率
  const { data: rateStats } = await supabase
    .from('anime_videos')
    .select('interaction_rate');

  const avgInteractionRate = rateStats && rateStats.length > 0
    ? rateStats.reduce((sum, v) => sum + (Number(v.interaction_rate) || 0), 0) / rateStats.length
    : 0;

  return {
    totalVideos: totalVideos || 0,
    totalViews,
    totalInteractions,
    avgInteractionRate: avgInteractionRate.toFixed(4)
  };
}

// 平台对比
async function getPlatformComparison(supabase: ReturnType<typeof getSupabaseClient>) {
  const platforms = ['bilibili', 'douyin'];
  const result: Record<string, { videos: number; views: number; likes: number; avgRate: number }> = {};

  for (const platform of platforms) {
    const { count: videos } = await supabase
      .from('anime_videos')
      .select('*', { count: 'exact', head: true })
      .eq('platform', platform);

    const { data } = await supabase
      .from('anime_videos')
      .select('view_count, like_count, interaction_rate')
      .eq('platform', platform);

    const views = data?.reduce((sum, v) => sum + (v.view_count || 0), 0) || 0;
    const likes = data?.reduce((sum, v) => sum + (v.like_count || 0), 0) || 0;
    const avgRate = data && data.length > 0
      ? data.reduce((sum, v) => sum + (Number(v.interaction_rate) || 0), 0) / data.length
      : 0;

    result[platform] = {
      videos: videos || 0,
      views,
      likes,
      avgRate: Number(avgRate.toFixed(4))
    };
  }

  return result;
}

// 排行榜
async function getRanking(
  supabase: ReturnType<typeof getSupabaseClient>, 
  platform: string | null, 
  limit: number = 10
) {
  let query = supabase
    .from('anime_videos')
    .select('id, platform, title, author, view_count, like_count, interaction_rate, rank_score, video_url, cover_url')
    .order('view_count', { ascending: false })
    .limit(limit);

  if (platform && platform !== 'all') {
    query = query.eq('platform', platform);
  }

  const { data, error } = await query;

  if (error) {
    throw new Error(`Ranking query failed: ${error.message}`);
  }

  return data;
}

// 趋势分析（按日期）
async function getTrendStats(supabase: ReturnType<typeof getSupabaseClient>, days: number = 7) {
  const { data, error } = await supabase
    .from('video_stats')
    .select('*')
    .order('stat_date', { ascending: false })
    .limit(days * 2); // 获取足够的数据

  if (error) {
    throw new Error(`Trend query failed: ${error.message}`);
  }

  // 按日期和平台分组
  const trendData: Record<string, Record<string, { videos: number; views: number; likes: number }>> = {};

  data?.forEach(stat => {
    const date = stat.stat_date?.split('T')[0] || '';
    const platform = stat.platform;

    if (!trendData[date]) {
      trendData[date] = {};
    }
    trendData[date][platform] = {
      videos: stat.total_videos || 0,
      views: stat.total_views || 0,
      likes: stat.total_likes || 0
    };
  });

  // 转换为数组格式
  const result = Object.entries(trendData)
    .sort((a, b) => a[0].localeCompare(b[0]))
    .slice(-days)
    .map(([date, platforms]) => ({
      date,
      bilibili: platforms.bilibili || { videos: 0, views: 0, likes: 0 },
      douyin: platforms.douyin || { videos: 0, views: 0, likes: 0 }
    }));

  return result;
}

// 热门标签
async function getTopTags(supabase: ReturnType<typeof getSupabaseClient>, limit: number = 10) {
  const { data, error } = await supabase
    .from('anime_videos')
    .select('tags')
    .not('tags', 'is', null);

  if (error) {
    throw new Error(`Tags query failed: ${error.message}`);
  }

  const tagCounts: Record<string, number> = {};
  data?.forEach(item => {
    if (item.tags) {
      item.tags.split(',').forEach((tag: string) => {
        const trimmedTag = tag.trim();
        if (trimmedTag) {
          tagCounts[trimmedTag] = (tagCounts[trimmedTag] || 0) + 1;
        }
      });
    }
  });

  return Object.entries(tagCounts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([tag, count]) => ({ tag, count }));
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type') || 'overview';
    const platform = searchParams.get('platform');
    const days = parseInt(searchParams.get('days') || '7');
    const limit = parseInt(searchParams.get('limit') || '10');

    const supabase = getSupabaseClient();

    let data;

    switch (type) {
      case 'overview':
        data = await getOverviewStats(supabase);
        break;
      case 'platform':
        data = await getPlatformComparison(supabase);
        break;
      case 'ranking':
        data = await getRanking(supabase, platform, limit);
        break;
      case 'trend':
        data = await getTrendStats(supabase, days);
        break;
      case 'tags':
        data = await getTopTags(supabase, limit);
        break;
      default:
        data = await getOverviewStats(supabase);
    }

    return NextResponse.json({
      success: true,
      type,
      data
    });

  } catch (error) {
    console.error('Stats API error:', error);
    return NextResponse.json(
      { 
        success: false, 
        error: error instanceof Error ? error.message : 'Unknown error' 
      },
      { status: 500 }
    );
  }
}
