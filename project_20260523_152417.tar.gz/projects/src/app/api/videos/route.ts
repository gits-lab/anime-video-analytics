import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';

// 视频数据接口
interface Video {
  id: number;
  platform: string;
  title: string;
  author: string;
  video_url: string;
  view_count: number;
  like_count: number;
  comment_count: number;
  favorite_count: number;
  share_count: number;
  publish_time: string | null;
  tags: string | null;
  cover_url: string | null;
  description: string | null;
  interaction_rate: number | null;
  rank_score: number | null;
  trend_score: number | null;
  last_crawled_at: string;
  created_at: string;
  updated_at: string | null;
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const platform = searchParams.get('platform');
    const keyword = searchParams.get('keyword');
    const sortBy = searchParams.get('sortBy') || 'view_count';
    const sortOrder = searchParams.get('sortOrder') || 'desc';
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const offset = (page - 1) * limit;

    const supabase = getSupabaseClient();

    // 构建查询
    let query = supabase
      .from('anime_videos')
      .select('*', { count: 'exact' });

    // 平台筛选
    if (platform && platform !== 'all') {
      query = query.eq('platform', platform);
    }

    // 关键词搜索
    if (keyword) {
      query = query.or(`title.ilike.%${keyword}%,author.ilike.%${keyword}%,tags.ilike.%${keyword}%`);
    }

    // 排序
    const ascending = sortOrder === 'asc';
    query = query.order(sortBy, { ascending });

    // 分页
    query = query.range(offset, offset + limit - 1);

    const { data, error, count } = await query;

    if (error) {
      throw new Error(`Query failed: ${error.message}`);
    }

    return NextResponse.json({
      success: true,
      data: data as Video[],
      pagination: {
        page,
        limit,
        total: count || 0,
        totalPages: Math.ceil((count || 0) / limit)
      }
    });

  } catch (error) {
    console.error('Videos API error:', error);
    return NextResponse.json(
      { 
        success: false, 
        error: error instanceof Error ? error.message : 'Unknown error' 
      },
      { status: 500 }
    );
  }
}

// 导出数据
export async function POST(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const format = searchParams.get('format') || 'json';
    const platform = searchParams.get('platform');
    
    const supabase = getSupabaseClient();

    let query = supabase
      .from('anime_videos')
      .select('*');

    if (platform && platform !== 'all') {
      query = query.eq('platform', platform);
    }

    const { data, error } = await query.order('view_count', { ascending: false }).limit(1000);

    if (error) {
      throw new Error(`Export failed: ${error.message}`);
    }

    if (format === 'csv') {
      // 生成 CSV
      const headers = ['平台', '标题', '作者', '播放量', '点赞', '评论', '收藏', '分享', '互动率', '标签', '链接'];
      const rows = (data as Video[]).map(v => [
        v.platform,
        `"${v.title.replace(/"/g, '""')}"`,
        `"${v.author.replace(/"/g, '""')}"`,
        v.view_count,
        v.like_count,
        v.comment_count,
        v.favorite_count,
        v.share_count,
        v.interaction_rate,
        v.tags || '',
        v.video_url
      ]);

      const csv = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
      
      return new NextResponse(csv, {
        headers: {
          'Content-Type': 'text/csv; charset=utf-8',
          'Content-Disposition': 'attachment; filename="anime_videos.csv"'
        }
      });
    }

    return NextResponse.json({
      success: true,
      data,
      count: data?.length || 0
    });

  } catch (error) {
    console.error('Export API error:', error);
    return NextResponse.json(
      { 
        success: false, 
        error: error instanceof Error ? error.message : 'Unknown error' 
      },
      { status: 500 }
    );
  }
}
