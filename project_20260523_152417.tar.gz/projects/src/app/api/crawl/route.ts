import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import {
  searchBilibiliVideos,
  getVideoDetail,
  getRankingVideos,
  getPopularVideos,
  type BilibiliVideo,
} from '@/lib/bilibili-api';

// 爬取关键词配置
const DEFAULT_KEYWORDS = ['动漫', '二次元', '新番', '动漫解说', '混剪', '国漫', '日漫'];

// 爬取结果接口
interface CrawledVideo {
  platform: string;
  title: string;
  author: string;
  video_url: string;
  view_count: number;
  like_count: number;
  comment_count: number;
  favorite_count: number;
  share_count: number;
  publish_time: string | null;
  tags: string;
  cover_url: string | null;
  description: string | null;
}

/**
 * 将B站视频数据转换为标准格式
 */
function convertBilibiliVideo(video: BilibiliVideo): CrawledVideo {
  return {
    platform: 'bilibili',
    title: video.title,
    author: video.author,
    video_url: video.video_url,
    view_count: video.view_count,
    like_count: video.like_count,
    comment_count: video.comment_count,
    favorite_count: video.favorite_count,
    share_count: video.share_count,
    publish_time: video.pubdate ? new Date(video.pubdate).toISOString() : null,
    tags: video.tags.join(','),
    cover_url: video.pic,
    description: video.desc,
  };
}

/**
 * 计算互动率
 */
function calculateInteractionRate(video: CrawledVideo): number {
  if (video.view_count === 0) return 0;
  const interactions = video.like_count + video.comment_count + video.favorite_count + video.share_count;
  return parseFloat((interactions / video.view_count * 100).toFixed(4));
}

/**
 * 计算排名分数
 */
function calculateRankScore(video: CrawledVideo): number {
  // 综合播放量、互动量计算排名分数
  const viewScore = Math.log10(video.view_count + 1) * 10;
  const interactionScore = Math.log10(video.like_count + video.comment_count + video.favorite_count + 1) * 5;
  return Math.round((viewScore + interactionScore) * 100) / 100;
}

/**
 * POST /api/crawl - 执行数据爬取
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json().catch(() => ({}));
    const {
      keywords = DEFAULT_KEYWORDS,
      count = 20,
      useRanking = true, // 是否获取排行榜数据
    } = body;

    console.log(`[Crawl] 开始爬取，关键词: ${keywords.join(', ')}, 数量: ${count}`);

    const supabase = getSupabaseClient();
    const allVideos: CrawledVideo[] = [];
    const seenUrls = new Set<string>();
    let errors: string[] = [];

    // 1. 获取B站动画区排行榜数据
    if (useRanking) {
      console.log('[Crawl] 正在获取B站动画区排行榜...');
      try {
        const rankingVideos = await getRankingVideos(13); // 13 = 动画分区
        console.log(`[Crawl] 排行榜获取到 ${rankingVideos.length} 个视频`);
        
        for (const video of rankingVideos) {
          if (!seenUrls.has(video.video_url)) {
            allVideos.push(convertBilibiliVideo(video));
            seenUrls.add(video.video_url);
          }
        }
      } catch (error) {
        const errorMsg = `排行榜获取失败: ${error}`;
        console.error(`[Crawl] ${errorMsg}`);
        errors.push(errorMsg);
      }
      
      // 延迟避免请求过快
      await new Promise(resolve => setTimeout(resolve, 500));
    }

    // 2. 搜索关键词获取视频
    for (const keyword of keywords) {
      console.log(`[Crawl] 正在搜索: ${keyword}`);
      
      try {
        // 搜索视频
        const searchResults = await searchBilibiliVideos(keyword, 1, Math.ceil(count / keywords.length));
        console.log(`[Crawl] 搜索 "${keyword}" 找到 ${searchResults.length} 个视频`);

        // 获取视频详情（包含完整的统计数据）
        for (let i = 0; i < Math.min(searchResults.length, 10); i++) {
          const searchVideo = searchResults[i];
          if (seenUrls.has(searchVideo.video_url)) continue;

          // 获取详细信息
          await new Promise(resolve => setTimeout(resolve, 200)); // 延迟避免请求过快
          
          const detail = await getVideoDetail(searchVideo.bvid);
          if (detail) {
            allVideos.push(convertBilibiliVideo(detail));
            seenUrls.add(detail.video_url);
          } else {
            // 如果获取详情失败，使用搜索结果
            allVideos.push(convertBilibiliVideo(searchVideo));
            seenUrls.add(searchVideo.video_url);
          }
        }
      } catch (error) {
        const errorMsg = `搜索 "${keyword}" 失败: ${error}`;
        console.error(`[Crawl] ${errorMsg}`);
        errors.push(errorMsg);
      }

      // 关键词间延迟
      await new Promise(resolve => setTimeout(resolve, 500));
    }

    console.log(`[Crawl] 共获取 ${allVideos.length} 个视频`);

    // 3. 存储到数据库
    let insertedCount = 0;
    const insertErrors: string[] = [];

    for (const video of allVideos) {
      try {
        const interactionRate = calculateInteractionRate(video);
        const rankScore = calculateRankScore(video);

        const { error } = await supabase
          .from('anime_videos')
          .upsert(
            {
              platform: video.platform,
              title: video.title,
              author: video.author,
              video_url: video.video_url,
              view_count: video.view_count,
              like_count: video.like_count,
              comment_count: video.comment_count,
              favorite_count: video.favorite_count,
              share_count: video.share_count,
              publish_time: video.publish_time,
              tags: video.tags,
              cover_url: video.cover_url,
              description: video.description,
              interaction_rate: interactionRate,
              rank_score: rankScore,
              trend_score: 0,
              updated_at: new Date().toISOString(),
            },
            {
              onConflict: 'video_url',
              ignoreDuplicates: false,
            }
          );

        if (error) {
          console.error(`[Crawl] 插入失败 (${video.title}):`, error.message);
          insertErrors.push(error.message);
        } else {
          insertedCount++;
        }
      } catch (err) {
        console.error(`[Crawl] 插入异常:`, err);
      }
    }

    // 4. 创建爬取任务记录
    const { data: taskData, error: taskError } = await supabase
      .from('crawl_tasks')
      .insert({
        keyword: keywords.join(','),
        platform: 'bilibili',
        status: insertErrors.length > 0 ? 'partial' : 'completed',
        result_count: insertedCount,
        started_at: new Date().toISOString(),
        completed_at: new Date().toISOString(),
      })
      .select('id')
      .single();

    const taskId = taskData?.id || 0;

    console.log(`[Crawl] 爬取完成: 插入 ${insertedCount} 条记录`);

    return NextResponse.json({
      success: true,
      message: `成功爬取 ${insertedCount} 个视频数据`,
      task_id: taskId,
      videos_count: insertedCount,
      details: {
        keywords_used: keywords,
        raw_results: allVideos.length,
        inserted: insertedCount,
        errors: errors.length > 0 ? errors : undefined,
        insert_errors: insertErrors.length > 0 ? insertErrors.slice(0, 5) : undefined,
      },
    });
  } catch (error) {
    console.error('[Crawl] 爬取失败:', error);
    return NextResponse.json(
      {
        success: false,
        message: `爬取失败: ${error}`,
        error: String(error),
      },
      { status: 500 }
    );
  }
}

/**
 * GET /api/crawl - 获取爬取任务列表
 */
export async function GET(request: NextRequest) {
  try {
    const supabase = getSupabaseClient();
    const { data, error } = await supabase
      .from('crawl_tasks')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(20);

    if (error) {
      return NextResponse.json({ success: false, error: error.message }, { status: 500 });
    }

    return NextResponse.json({
      success: true,
      tasks: data,
    });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: String(error) },
      { status: 500 }
    );
  }
}
