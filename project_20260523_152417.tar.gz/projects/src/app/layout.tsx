import type { Metadata } from 'next';
import { Inspector } from 'react-dev-inspector';
import './globals.css';

export const metadata: Metadata = {
  title: {
    default: '动漫视频数据分析 | 扣子编程',
    template: '%s | 动漫视频数据分析',
  },
  description:
    '动漫视频数据分析平台 - 监控B站和抖音动漫视频数据，提供播放量排行、平台对比、趋势分析等功能。',
  keywords: [
    '动漫数据分析',
    'B站数据',
    '抖音数据',
    '二次元',
    '新番',
    '动漫排行榜',
    '视频数据分析',
  ],
  authors: [{ name: 'Coze Code Team', url: 'https://code.coze.cn' }],
  generator: 'Coze Code',
  openGraph: {
    title: '动漫视频数据分析平台',
    description:
      '实时监控B站和抖音动漫视频数据，提供播放量排行、平台对比、趋势分析等功能。',
    url: 'https://code.coze.cn',
    siteName: '动漫视频数据分析',
    locale: 'zh_CN',
    type: 'website',
  },
  //   // images: [''],
  // },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const isDev = process.env.COZE_PROJECT_ENV === 'DEV';

  return (
    <html lang="en">
      <body className={`antialiased`}>
        {isDev && <Inspector />}
        {children}
      </body>
    </html>
  );
}
