'use client';

import { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  ChartConfig,
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from '@/components/ui/chart';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, LineChart, Line, PieChart, Pie, Cell, ResponsiveContainer, Legend } from 'recharts';
import { Play, TrendingUp, Users, ThumbsUp, Download, RefreshCw, ExternalLink, Search } from 'lucide-react';

// 类型定义
interface Video {
  id: number;
  platform: string;
  title: string;
  author: string;
  video_url: string;
  view_count: number;
  like_count: number;
  comment_count: number;
  favorite_count: number;
  share_count: number;
  publish_time: string | null;
  tags: string | null;
  cover_url: string | null;
  interaction_rate: number | null;
  rank_score: number | null;
}

interface OverviewStats {
  totalVideos: number;
  totalViews: number;
  totalInteractions: number;
  avgInteractionRate: string;
}

interface PlatformStats {
  videos: number;
  views: number;
  likes: number;
  avgRate: number;
}

interface TrendData {
  date: string;
  bilibili: { videos: number; views: number; likes: number };
  douyin: { videos: number; views: number; likes: number };
}

// 颜色配置
const COLORS = {
  bilibili: '#00a1d6',
  douyin: '#161823',
  primary: '#f97316',
  success: '#22c55e',
  warning: '#eab308',
};

const chartConfig: ChartConfig = {
  views: { label: '播放量' },
  likes: { label: '点赞数' },
  videos: { label: '视频数' },
  bilibili: { label: 'B站', color: COLORS.bilibili },
  douyin: { label: '抖音', color: COLORS.douyin },
};

// 格式化数字
function formatNumber(num: number): string {
  if (num >= 100000000) {
    return (num / 100000000).toFixed(2) + '亿';
  }
  if (num >= 10000) {
    return (num / 10000).toFixed(1) + '万';
  }
  return num.toLocaleString();
}

// 主组件
export default function Dashboard() {
  const [loading, setLoading] = useState(true);
  const [crawling, setCrawling] = useState(false);
  const [overview, setOverview] = useState<OverviewStats | null>(null);
  const [platformStats, setPlatformStats] = useState<Record<string, PlatformStats> | null>(null);
  const [ranking, setRanking] = useState<Video[]>([]);
  const [trendData, setTrendData] = useState<TrendData[]>([]);
  const [videos, setVideos] = useState<Video[]>([]);
  const [topTags, setTopTags] = useState<{ tag: string; count: number }[]>([]);
  
  // 筛选状态
  const [platformFilter, setPlatformFilter] = useState('all');
  const [searchKeyword, setSearchKeyword] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  // 获取概览数据
  const fetchOverview = useCallback(async () => {
    try {
      const res = await fetch('/api/stats?type=overview');
      const data = await res.json();
      if (data.success) {
        setOverview(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch overview:', error);
    }
  }, []);

  // 获取平台对比
  const fetchPlatformStats = useCallback(async () => {
    try {
      const res = await fetch('/api/stats?type=platform');
      const data = await res.json();
      if (data.success) {
        setPlatformStats(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch platform stats:', error);
    }
  }, []);

  // 获取排行榜
  const fetchRanking = useCallback(async (platform: string = 'all') => {
    try {
      const res = await fetch(`/api/stats?type=ranking&platform=${platform}&limit=10`);
      const data = await res.json();
      if (data.success) {
        setRanking(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch ranking:', error);
    }
  }, []);

  // 获取趋势数据
  const fetchTrend = useCallback(async () => {
    try {
      const res = await fetch('/api/stats?type=trend&days=7');
      const data = await res.json();
      if (data.success) {
        setTrendData(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch trend:', error);
    }
  }, []);

  // 获取热门标签
  const fetchTopTags = useCallback(async () => {
    try {
      const res = await fetch('/api/stats?type=tags&limit=10');
      const data = await res.json();
      if (data.success) {
        setTopTags(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch tags:', error);
    }
  }, []);

  // 获取视频列表
  const fetchVideos = useCallback(async (page: number = 1, platform: string = 'all', keyword: string = '') => {
    try {
      const params = new URLSearchParams({
        page: page.toString(),
        limit: '10',
        ...(platform !== 'all' && { platform }),
        ...(keyword && { keyword })
      });
      const res = await fetch(`/api/videos?${params}`);
      const data = await res.json();
      if (data.success) {
        setVideos(data.data);
        setTotalPages(data.pagination.totalPages);
        setCurrentPage(data.pagination.page);
      }
    } catch (error) {
      console.error('Failed to fetch videos:', error);
    }
  }, []);

  // 执行爬取
  const handleCrawl = async () => {
    setCrawling(true);
    try {
      const res = await fetch('/api/crawl', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          platforms: ['bilibili', 'douyin'],
          keywords: ['动漫', '二次元', '新番'],
          count: 10
        })
      });
      const data = await res.json();
      if (data.success) {
        // 刷新数据
        await Promise.all([
          fetchOverview(),
          fetchPlatformStats(),
          fetchRanking(platformFilter),
          fetchTrend(),
          fetchTopTags(),
          fetchVideos(1, platformFilter, searchKeyword)
        ]);
      }
    } catch (error) {
      console.error('Crawl failed:', error);
    } finally {
      setCrawling(false);
    }
  };

  // 导出数据
  const handleExport = async (format: 'json' | 'csv') => {
    try {
      const res = await fetch(`/api/videos?format=${format}&platform=${platformFilter}`, {
        method: 'POST'
      });
      
      if (format === 'csv') {
        const blob = await res.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'anime_videos.csv';
        a.click();
        window.URL.revokeObjectURL(url);
      } else {
        const data = await res.json();
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'anime_videos.json';
        a.click();
        window.URL.revokeObjectURL(url);
      }
    } catch (error) {
      console.error('Export failed:', error);
    }
  };

  // 初始化数据
  useEffect(() => {
    const init = async () => {
      setLoading(true);
      await Promise.all([
        fetchOverview(),
        fetchPlatformStats(),
        fetchRanking(),
        fetchTrend(),
        fetchTopTags(),
        fetchVideos()
      ]);
      setLoading(false);
    };
    init();
  }, [fetchOverview, fetchPlatformStats, fetchRanking, fetchTrend, fetchTopTags, fetchVideos]);

  // 平台筛选变化
  useEffect(() => {
    if (!loading) {
      fetchRanking(platformFilter);
      fetchVideos(1, platformFilter, searchKeyword);
    }
  }, [platformFilter, loading, fetchRanking, fetchVideos, searchKeyword]);

  // 准备图表数据
  const platformChartData = platformStats ? [
    { name: 'B站', videos: platformStats.bilibili?.videos || 0, views: platformStats.bilibili?.views || 0, likes: platformStats.bilibili?.likes || 0 },
    { name: '抖音', videos: platformStats.douyin?.videos || 0, views: platformStats.douyin?.views || 0, likes: platformStats.douyin?.likes || 0 },
  ] : [];

  const trendChartData = trendData.map(item => ({
    date: item.date.slice(5), // MM-DD
    'B站播放': item.bilibili.views,
    '抖音播放': item.douyin.views,
  }));

  const tagPieData = topTags.slice(0, 6).map((item, index) => ({
    name: item.tag,
    value: item.count,
    color: ['#f97316', '#00a1d6', '#22c55e', '#eab308', '#ef4444', '#8b5cf6'][index]
  }));

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          <Skeleton className="h-12 w-64" />
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-32" />)}
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Skeleton className="h-80" />
            <Skeleton className="h-80" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white">
      {/* 顶部导航 */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-orange-500 to-orange-600 flex items-center justify-center">
              <Play className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-800">动漫视频数据分析</h1>
              <p className="text-xs text-slate-500">B站 & 抖音数据监控平台</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Select value={platformFilter} onValueChange={setPlatformFilter}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="选择平台" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部平台</SelectItem>
                <SelectItem value="bilibili">B站</SelectItem>
                <SelectItem value="douyin">抖音</SelectItem>
              </SelectContent>
            </Select>
            <Button onClick={handleCrawl} disabled={crawling} className="bg-orange-500 hover:bg-orange-600">
              {crawling ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  爬取中...
                </>
              ) : (
                <>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  更新数据
                </>
              )}
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-6 space-y-6">
        {/* 概览卡片 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="border-l-4 border-l-orange-500">
            <CardHeader className="pb-2">
              <CardDescription className="flex items-center gap-2">
                <Play className="w-4 h-4" />
                总视频数
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-slate-800">
                {formatNumber(overview?.totalVideos || 0)}
              </div>
            </CardContent>
          </Card>
          <Card className="border-l-4 border-l-blue-500">
            <CardHeader className="pb-2">
              <CardDescription className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                总播放量
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-slate-800">
                {formatNumber(overview?.totalViews || 0)}
              </div>
            </CardContent>
          </Card>
          <Card className="border-l-4 border-l-green-500">
            <CardHeader className="pb-2">
              <CardDescription className="flex items-center gap-2">
                <Users className="w-4 h-4" />
                总互动量
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-slate-800">
                {formatNumber(overview?.totalInteractions || 0)}
              </div>
            </CardContent>
          </Card>
          <Card className="border-l-4 border-l-purple-500">
            <CardHeader className="pb-2">
              <CardDescription className="flex items-center gap-2">
                <ThumbsUp className="w-4 h-4" />
                平均互动率
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-slate-800">
                {overview?.avgInteractionRate || '0'}%
              </div>
            </CardContent>
          </Card>
        </div>

        {/* 图表区域 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* 排行榜 */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">播放量排行榜</CardTitle>
              <CardDescription>视频播放量 Top 10</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {ranking.slice(0, 10).map((video, index) => (
                  <div key={video.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-slate-50 transition-colors">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-sm ${
                      index === 0 ? 'bg-yellow-500' : index === 1 ? 'bg-slate-400' : index === 2 ? 'bg-amber-600' : 'bg-slate-300'
                    }`}>
                      {index + 1}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline" className={
                          video.platform === 'bilibili' ? 'border-blue-500 text-blue-500' : 'border-slate-500 text-slate-500'
                        }>
                          {video.platform === 'bilibili' ? 'B站' : '抖音'}
                        </Badge>
                        <p className="text-sm font-medium truncate">{video.title}</p>
                      </div>
                      <p className="text-xs text-slate-500">{video.author}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-semibold text-orange-500">{formatNumber(video.view_count)}</p>
                      <p className="text-xs text-slate-500">播放</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* 平台对比 */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">平台数据对比</CardTitle>
              <CardDescription>B站 vs 抖音 核心指标对比</CardDescription>
            </CardHeader>
            <CardContent>
              <ChartContainer config={chartConfig} className="h-64">
                <BarChart data={platformChartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="name" tick={{ fill: '#64748b' }} />
                  <YAxis tick={{ fill: '#64748b' }} tickFormatter={formatNumber} />
                  <ChartTooltip content={<ChartTooltipContent />} />
                  <Bar dataKey="views" name="播放量" fill="#00a1d6" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="likes" name="点赞数" fill="#f97316" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ChartContainer>
            </CardContent>
          </Card>
        </div>

        {/* 趋势与标签 */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* 趋势图 */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="text-lg">数据趋势</CardTitle>
              <CardDescription>近7天播放量趋势</CardDescription>
            </CardHeader>
            <CardContent>
              {trendChartData.length > 0 ? (
                <ChartContainer config={chartConfig} className="h-64">
                  <LineChart data={trendChartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                    <XAxis dataKey="date" tick={{ fill: '#64748b' }} />
                    <YAxis tick={{ fill: '#64748b' }} tickFormatter={formatNumber} />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Legend />
                    <Line type="monotone" dataKey="B站播放" stroke="#00a1d6" strokeWidth={2} dot={{ fill: '#00a1d6' }} />
                    <Line type="monotone" dataKey="抖音播放" stroke="#161823" strokeWidth={2} dot={{ fill: '#161823' }} />
                  </LineChart>
                </ChartContainer>
              ) : (
                <div className="h-64 flex items-center justify-center text-slate-400">
                  暂无趋势数据，请先爬取数据
                </div>
              )}
            </CardContent>
          </Card>

          {/* 热门标签 */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">热门标签</CardTitle>
              <CardDescription>内容标签分布</CardDescription>
            </CardHeader>
            <CardContent>
              {tagPieData.length > 0 ? (
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={tagPieData}
                        cx="50%"
                        cy="50%"
                        innerRadius={50}
                        outerRadius={80}
                        paddingAngle={2}
                        dataKey="value"
                      >
                        {tagPieData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              ) : (
                <div className="h-64 flex items-center justify-center text-slate-400">
                  暂无标签数据
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* 数据表格 */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-lg">数据明细</CardTitle>
                <CardDescription>完整视频数据列表</CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <Input
                    placeholder="搜索标题/作者/标签..."
                    className="pl-9 w-64"
                    value={searchKeyword}
                    onChange={(e) => setSearchKeyword(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && fetchVideos(1, platformFilter, searchKeyword)}
                  />
                </div>
                <Button variant="outline" size="sm" onClick={() => handleExport('json')}>
                  <Download className="w-4 h-4 mr-1" />
                  JSON
                </Button>
                <Button variant="outline" size="sm" onClick={() => handleExport('csv')}>
                  <Download className="w-4 h-4 mr-1" />
                  CSV
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-16">平台</TableHead>
                    <TableHead>标题</TableHead>
                    <TableHead>UP主</TableHead>
                    <TableHead className="text-right">播放量</TableHead>
                    <TableHead className="text-right">点赞</TableHead>
                    <TableHead className="text-right">互动率</TableHead>
                    <TableHead>标签</TableHead>
                    <TableHead className="w-16">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {videos.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center text-slate-400 py-8">
                        暂无数据，请点击"更新数据"开始爬取
                      </TableCell>
                    </TableRow>
                  ) : (
                    videos.map((video) => (
                      <TableRow key={video.id} className="hover:bg-slate-50">
                        <TableCell>
                          <Badge variant="outline" className={
                            video.platform === 'bilibili' ? 'border-blue-500 text-blue-500' : 'border-slate-500 text-slate-500'
                          }>
                            {video.platform === 'bilibili' ? 'B站' : '抖音'}
                          </Badge>
                        </TableCell>
                        <TableCell className="max-w-xs truncate font-medium">{video.title}</TableCell>
                        <TableCell>{video.author}</TableCell>
                        <TableCell className="text-right font-semibold">{formatNumber(video.view_count)}</TableCell>
                        <TableCell className="text-right">{formatNumber(video.like_count)}</TableCell>
                        <TableCell className="text-right">
                          <span className={video.interaction_rate && video.interaction_rate > 5 ? 'text-green-500' : ''}>
                            {video.interaction_rate?.toFixed(2) || '0'}%
                          </span>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-1">
                            {video.tags?.split(',').slice(0, 3).map((tag, i) => (
                              <Badge key={i} variant="secondary" className="text-xs">{tag.trim()}</Badge>
                            ))}
                          </div>
                        </TableCell>
                        <TableCell>
                          <a href={video.video_url} target="_blank" rel="noopener noreferrer">
                            <Button variant="ghost" size="icon">
                              <ExternalLink className="w-4 h-4" />
                            </Button>
                          </a>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
            
            {/* 分页 */}
            {totalPages > 1 && (
              <div className="flex items-center justify-center gap-2 mt-4">
                <Button
                  variant="outline"
                  size="sm"
                  disabled={currentPage === 1}
                  onClick={() => fetchVideos(currentPage - 1, platformFilter, searchKeyword)}
                >
                  上一页
                </Button>
                <span className="text-sm text-slate-500">
                  第 {currentPage} / {totalPages} 页
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  disabled={currentPage === totalPages}
                  onClick={() => fetchVideos(currentPage + 1, platformFilter, searchKeyword)}
                >
                  下一页
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* 免责声明 */}
        <Card className="bg-slate-50 border-slate-200">
          <CardContent className="py-4">
            <p className="text-xs text-slate-500 text-center">
              本工具仅用于学习和数据分析目的，爬取公开非隐私数据，禁止商用及批量引流。
              数据来源：B站、抖音公开数据。
            </p>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
