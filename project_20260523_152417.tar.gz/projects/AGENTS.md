# 项目上下文

## 项目概述
动漫视频数据分析平台 - 监控B站和抖音动漫视频数据，提供播放量排行、平台对比、趋势分析等功能。

### 版本技术栈

- **Framework**: Next.js 16 (App Router)
- **Core**: React 19
- **Language**: TypeScript 5
- **UI 组件**: shadcn/ui (基于 Radix UI)
- **Styling**: Tailwind CSS 4
- **Database**: Supabase (PostgreSQL)
- **Charts**: Recharts

## 目录结构

```
├── public/                 # 静态资源
├── scripts/                # 构建与启动脚本
├── src/
│   ├── app/                # 页面路由与布局
│   │   ├── api/            # API 路由
│   │   │   ├── crawl/      # 数据爬取 API
│   │   │   ├── cron/       # 定时任务 API
│   │   │   ├── stats/      # 统计数据 API
│   │   │   └── videos/     # 视频数据 API
│   │   ├── globals.css     # 全局样式
│   │   ├── layout.tsx      # 根布局
│   │   └── page.tsx        # 主页面（数据仪表板）
│   ├── components/ui/      # Shadcn UI 组件库
│   ├── hooks/              # 自定义 Hooks
│   ├── lib/                # 工具库
│   │   └── utils.ts        # 通用工具函数 (cn)
│   └── storage/            # 数据存储
│       └── database/       # 数据库配置
│           ├── supabase-client.ts  # Supabase 客户端
│           └── shared/     # 共享数据模型
│               └── schema.ts # 数据库表结构定义
├── next.config.ts          # Next.js 配置
├── package.json            # 项目依赖管理
└── tsconfig.json           # TypeScript 配置
```

## 包管理规范

**仅允许使用 pnpm** 作为包管理器，**严禁使用 npm 或 yarn**。
**常用命令**：
- 安装依赖：`pnpm add <package>`
- 安装开发依赖：`pnpm add -D <package>`
- 安装所有依赖：`pnpm install`
- 移除依赖：`pnpm remove <package>`

## 数据库表结构

### anime_videos (动漫视频表)
- `id`: 主键
- `platform`: 平台 (bilibili/douyin)
- `title`: 视频标题
- `author`: UP主/作者
- `video_url`: 视频链接（唯一）
- `view_count`: 播放量
- `like_count`: 点赞数
- `comment_count`: 评论数
- `favorite_count`: 收藏数
- `share_count`: 分享数
- `publish_time`: 发布时间
- `tags`: 标签
- `interaction_rate`: 互动率
- `rank_score`: 排名分数
- `trend_score`: 趋势分数

### crawl_tasks (爬取任务表)
- `id`: 主键
- `keyword`: 爬取关键词
- `platform`: 目标平台
- `status`: 任务状态
- `result_count`: 结果数量
- `started_at`: 开始时间
- `completed_at`: 完成时间

### video_stats (视频统计表)
- `id`: 主键
- `stat_date`: 统计日期
- `platform`: 平台
- `total_videos`: 视频总数
- `total_views`: 播放总量
- `total_likes`: 点赞总量
- `avg_interaction_rate`: 平均互动率
- `top_tags`: 热门标签

## API 端点

### 数据爬取
- `POST /api/crawl`: 执行数据爬取
  - Body: `{ platforms: string[], keywords: string[], count: number }`
  - 返回: `{ success: boolean, message: string, task_id: number, videos_count: number }`

### 统计数据
- `GET /api/stats?type=overview`: 获取概览统计
- `GET /api/stats?type=platform`: 获取平台对比
- `GET /api/stats?type=ranking`: 获取排行榜
- `GET /api/stats?type=trend&days=7`: 获取趋势数据
- `GET /api/stats?type=tags`: 获取热门标签

### 视频数据
- `GET /api/videos`: 获取视频列表（支持分页、筛选）
- `POST /api/videos?format=csv|json`: 导出数据

### 定时任务
- `GET /api/cron`: 健康检查
- `POST /api/cron`: 触发定时爬取

## 开发规范

### 编码规范
- 使用 TypeScript strict 模式
- 禁止隐式 `any`，所有参数必须有类型注解
- 字段名使用 snake_case（数据库）和 camelCase（前端）约定

### Hydration 问题防范
- 严禁在 JSX 渲染逻辑中直接使用 `typeof window`、`Date.now()` 等动态数据
- 必须使用 'use client' 并配合 useEffect + useState 确保动态内容仅在客户端渲染

## 功能说明

1. **数据爬取**: 使用 web-search 技能搜索 B站 和抖音的动漫视频公开数据
2. **数据存储**: 自动存储到 Supabase 数据库，计算互动率、排行和趋势指标
3. **可视化展示**: 
   - 概览卡片（总视频数、播放量、互动量、互动率）
   - 播放量排行榜 Top 10
   - 平台数据对比图
   - 趋势分析图表
   - 数据表格（支持筛选、导出）
4. **定时爬取**: 通过 `/api/cron` 端点支持外部定时任务调度

## 合规声明

本工具仅用于学习和数据分析目的，爬取公开非隐私数据，禁止商用及批量引流。
